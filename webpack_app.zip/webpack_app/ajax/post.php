<?php
if (isset($_POST['submit'])){
  $policy = $_POST['policy'];
  $age = $_POST['age'];
  $startDate = $_POST['startDate'];
  $endDate = $_POST['endDate'];
  $citizenship = $_POST['citizenship'];
  $state = $_POST['state'];

  $errorEmpty = false;
  if (empty($policy) || empty($age) || empty($startDate) || empty($endDate) || empty($citizenship) || empty($state)){
    echo "<span class='form-error'>This is required!</span>";
    $errorEmpty = true;
  }
  elseif(!$citizenship.matches("[aA-zZ ]+$")){
    echo "<span class='form-error'>This is not a valid country</span>";
  }
  elseif(!$state.matches("[aA-zZ ]+$")){
    echo "<span class='form-error'>This is not a valid state</span>";
  }
  else{
    echo "<span class='form-success'>Form Success!</span>";
  }
}
?>
