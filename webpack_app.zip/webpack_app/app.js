
var errorEmpty = "<?php echo $errorEmpty;?>";
$( document ).ready(function() {
  var form = $("#myForm");
  $('#reset').click(function(){
    form.trigger("reset");
  });
  var policy = $(".dropDown-List").val();
  if($.trim(policu) != ''){
    $.post('post.php',{policy: policy}, function(data){
      $("#results").html(data);
    });
  }
  form.submit(function(e){
    var policy = $("#policy").val();
    var age = $("#inputAge").val();
    var startDate = $("#inputStartDate").val();
    var endDate = $("#inputEndDate").val();
    var citizenship = $("#inputCitizenship").val();
    var state = $("#inputState").val();
    $(".form-message").load("post.php",{
      policy: policy,
      age: age,
      startDate : startDate,
      endDate : endDate,
      citizenship: citizenship,
      state:state
    });
    e.preventDefault();
  });
});
